package selenium.demo;

public class Employee {
	
	private String Full_Name;
	private int Age;
	private double Salary;
	
	protected double Level;
	
	public String getFullName()
	{
		return Full_Name;
	}
	
	public void setFullName(String Full_Name)
	{
		this.Full_Name = Full_Name;
	}
	
	
	public int getAge()
	{
		return Age;
	}
	
	public void setAge(int Age)
	{
		this.Age = Age;
	}
	
	
	public double getSalary()
	{
		return Salary;
	}
	
	public void setSalary(double Salary)
	{
		this.Salary = Salary;
	}
	
}
