package selenium.demo.list;
import selenium.demo.Employee;

public class EmployeeList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		
		employee.setFullName("Nhi");
		employee.setAge(27);
		employee.setSalary(7.5);
		
		System.out.println(employee.getFullName() + " " + employee.getAge() + " tuoi va co luong la " + employee.getSalary());
	}

}
