package NgayBa;

import NgayBa.Animal;
import java.util.ArrayList;

public class Exercise4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Animal> listAnimal = new ArrayList<Animal>() {};
		
		
		for(int i = 0; i < 4; i++)
		{
			listAnimal.add(new Animal());
			listAnimal.get(i).setName(animalName[i]);
			listAnimal.get(i).setWeight(animalWeight[i]);
			
			System.out.println(listAnimal.get(i).getName() + " is " + listAnimal.get(i).getWeight());
		}
	}

}
