package NgayBa;

public class Animal {
	
	private String name;
	private String weight;
	
	  public String getName() {
		    return name;
	  }

	  public void setName(String animalName) {
	    this.name = animalName;
	  }
	  
	  public String getWeight() {
		    return weight;
	  }
	
	  public void setWeight(String animalWeight) {
	    this.weight = animalWeight;
	  }
}
