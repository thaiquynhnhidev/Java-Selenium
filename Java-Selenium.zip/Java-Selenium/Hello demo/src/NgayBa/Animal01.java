package NgayBa;

import java.util.ArrayList;

public class Animal01 {
	
	private String name;
	private int height;
	
	public Animal01(String name, int height)
	{
		super();
		this.name = name;
		this.height = height;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String[] name = {"Cat", "Dog", "Fish", "Monkey"};
		int[] height = {1, 2, 3, 4};
		
		ArrayList<Animal01> animals = new ArrayList<Animal01>();
		for(int i = 0; i < 4; i++)
		{
			animals.add(new Animal01(name[i], height[i]));
		}
		
		for(Animal01 animal : animals)
		{
			System.out.println(animal.name + " " + animal.height);
		}
	}

}
