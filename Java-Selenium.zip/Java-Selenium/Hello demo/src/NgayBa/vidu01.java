package NgayBa;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class vidu01 {4
	
	//private int STT;
	private String Hoten;
	private String Ngaysinh;+
	
	public vidu01(String Hoten, String Ngaysinh) {
		super();
		//this.STT = STT;
		this.Hoten = Hoten;
		this.Ngaysinh = Ngaysinh;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.print("Nhap n: ");
		Scannerscanner  = new Scanner (System.in);
		int n = scanner.nextInt();
		
		String[] Hoten = new String[n];
		String[] Ngaysinh = new String[n];
		
		Hoten = inputArray(n, Hoten);
		ArrayList<String> HotenHS = new ArrayList<>(Arrays.asList(Hoten));
		//System.out.println("\nAnimal Name: " + Hoten);
		Ngaysinh = inputArray(n, Ngaysinh);
		ArrayList<String> NgaysinhHS = new ArrayList<>(Arrays.asList(Ngaysinh));
		//System.out.println("\nAnimal Weight: " + AnimalWeight);
		
		ArrayList<vidu01> Hocsinh = new ArrayList<vidu01>();
		
		for(int i = 0; i < n; i++)
		{
			Hocsinh.add(new vidu01(Hoten[i], Ngaysinh[i]));
		}
		
		for(vidu01 Hocsinhs : Hocsinh)
		{
			System.out.println(Hocsinhs.Hoten + " " + Hocsinhs.Ngaysinh);
		}
		
	}
	
	public static String[] inputArray(int n, String[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			System.out.print("So thu tu " + i + ": ");
			Scanner scanner = new Scanner (System.in);
			String a = scanner.next();
			data[i] = a;
		}
		return data;
	}

}
