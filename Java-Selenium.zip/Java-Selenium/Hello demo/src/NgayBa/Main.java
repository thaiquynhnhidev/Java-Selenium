package NgayBa;
import NgayBa.Person;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub 
	    
	    Person myObj = new Person();
	    myObj.setName("John"); // Set the value of the name variable to "John"
	    System.out.println(myObj.getName());
	}

}
