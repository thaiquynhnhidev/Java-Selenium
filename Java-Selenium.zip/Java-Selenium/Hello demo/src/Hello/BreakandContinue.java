package Hello;

public class BreakandContinue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Break and Continue
		//// Break
		int num[] = {2, 9, 1, 4, 25, 50};
		int search = 4;
		for(int i = 1; i < num.length; i++)
		{
			if(num[i] == search)
			{
				System.out.println("data is found!");
				break;
			}
		}
		
		//// Continue		
		for(int i = 1; i < num.length; i++)
		{
			if(num[i] != search)
			{
				continue;
			}
			if(num[i] == search)
			{
				System.out.println("data is found!");
				break;
			}
		}
	}

}
