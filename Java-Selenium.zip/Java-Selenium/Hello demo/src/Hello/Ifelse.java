package Hello;

import java.util.Scanner;

public class Ifelse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Input number");
		Scanner scanner = new Scanner (System.in);
		int number = scanner.nextInt();
		
		if (number >= 0 && number < 5)
		{
			System.out.print("Yeu");
		}
		else if (number >= 5 && number < 6)
		{
			System.out.print("Trung binh");
		}
		else if (number >= 6 && number < 8)
		{
			System.out.print("Kha");
		}
		else if (number >= 8 && number < 9)
		{
			System.out.print("Gioi");
		}
		else if (number >= 9 && number <= 10)
		{
			System.out.print("Xuat sac");
		}
		
	}

}
