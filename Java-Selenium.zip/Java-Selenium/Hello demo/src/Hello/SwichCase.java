package Hello;

import java.util.Scanner;

public class SwichCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Input number");
		Scanner scanner = new Scanner (System.in);
		int day = scanner.nextInt();
		
		switch (day) {
		case 2: 
			System.out.print("Thu hai");
			break;
		case 3:
			System.out.print("Thu ba");
			break;
		case 4:
			System.out.print("Thu tu");
			break;
		case 5:
			System.out.print("Thu nam");
			break;
		case 6:
			System.out.print("Thu sau");
			break;
		case 7:
			System.out.print("Thu bay");
			break;
		case 8:
			System.out.print("Chu nhat");
			break;
		}
	}

}
