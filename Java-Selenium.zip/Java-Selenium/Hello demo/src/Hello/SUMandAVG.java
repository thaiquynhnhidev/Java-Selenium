package Hello;

public class SUMandAVG {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count1 = 0;
		int sum1 = 0;
		while(count1 < 100)
		{
			count1++;
			sum1 += count1;
		}
		System.out.println("SUM:" + sum1);
		System.out.println("AVG:" + sum1/100);
		
		int count2 = 0;
		int sum2 = 0;
		do {
			count2++;
			sum2 += count2;
		} 
		while(count2 < 100);
		System.out.println("SUM:" + sum2);
		System.out.println("AVG:" + sum2/100);
			
		int count3;
		int sum3 = 0;
		for(count3 = 1; count3 <= 100; count3++)
		{
			sum3 += count3;
		}
		System.out.println("SUM:" + sum3);
		System.out.println("AVG:" + sum3/100);
		
	}	

}
