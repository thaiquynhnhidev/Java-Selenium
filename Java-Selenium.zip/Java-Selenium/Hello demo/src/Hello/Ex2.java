package Hello;

import java.util.Scanner;

public class Ex2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Input number");
		Scanner scanner = new Scanner (System.in);
		int number = scanner.nextInt();
		
		if(number % 2 == 0)
		{
			System.out.print("So chan");
		}
		else
			System.out.print("So le");
	}

}
