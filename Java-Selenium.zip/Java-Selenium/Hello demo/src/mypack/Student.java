package mypack;

public class Student {
	
	public String name;
	public int age;
	public float height;
	public String university;
	
	public Student(String name, int age, float height, String university)
	{
		this.name = name;
		this.age = age;
		this.height = height;
		this.university = university;
	}
	
	public void getInfo()
	{
		System.out.println("Name: " + this.name);
		System.out.println("Age: " + this.age);
		System.out.println("Height: " + this.height);
		System.out.println("University Name: " + this.university);
	}

	
	
}
