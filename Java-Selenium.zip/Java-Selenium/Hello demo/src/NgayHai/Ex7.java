package NgayHai;

import java.util.ArrayList;
import java.util.Collections;

public class Ex7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> listOfNames = new ArrayList<String>();
		
		listOfNames.add("Waritian Herkku");
		listOfNames.add("Wellington Importadora");
		listOfNames.add("White Clover Markets");
		listOfNames.add("Wilman Kala");
		listOfNames.add("Wolski");
		
		System.out.println("value at the first index: " + listOfNames.get(0));
		
		System.out.println("Before array: ");
		int arrSize = listOfNames.size();
		for(int i = 0; i < arrSize; i++)
		{
			System.out.println(i + ": " + listOfNames.get(i));
		}
		
		listOfNames.remove("Wilman Kala");
		listOfNames.remove(1);
		listOfNames.add(2, "Matti Karttunen");
		
		System.out.println("After array (Unsorted List): ");
		
		arrSize = listOfNames.size();
		for(int i = 0; i < arrSize; i++)
		{
			System.out.println(i + ": " + listOfNames.get(i));
		}
		
		Collections.sort(listOfNames);
		System.out.println("After Sorting");

		arrSize = listOfNames.size();
		for(int i = 0; i < arrSize; i++)
		{
			System.out.println(i + ": " + listOfNames.get(i));
		}
	}

}
