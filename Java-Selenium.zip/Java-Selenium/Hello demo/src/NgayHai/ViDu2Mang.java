package NgayHai;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ViDu2Mang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Create an array of String type
		System.out.print("Nhap n: ");
		Scanner scanner = new Scanner (System.in);
		int n = scanner.nextInt();
		String[] data = new String[n];
		data = inputArray(n, data);
		
		/*String[] arr = {"Dog", "Cat", "Horse"};
        System.out.print("Array: ");*/

        /*// Print array
        for(String str: arr) {
            System.out.print(str);
            System.out.print(" ");
        }*/

        // Create an ArrayList from an array
        ArrayList<String> animals = new ArrayList<>(Arrays.asList(data));
        System.out.println("\nArrayList: " + animals);
	}
	
	public static String[] inputArray(int n, String[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			System.out.print("data[" + i + "] = ");
			Scanner scanner = new Scanner (System.in);
			String a = scanner.next();
			data[i] = a;
		}
		return data;
	}

}
