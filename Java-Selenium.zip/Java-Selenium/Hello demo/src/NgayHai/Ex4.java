package NgayHai;

import java.util.Scanner;
import java.io.IOException;

public class Ex4 {
	
	@SuppressWarnings("resource")

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		System.out.print("Input a string: ");
		Scanner scanner = new Scanner(System.in);
		String userInput = scanner.nextLine();
		
		int len = userInput.length();
		int tu = 1;
		int i = 0;
		
		for(i = 0; i < len; i++)
		{
			if(userInput.charAt(i) == ' ')
			{
				tu++;
			}
		}
		
		System.out.println("So ki tu: " + i);
		System.out.println("So tu: " + tu);
		
		int laplai = 0;
		String[] a;
		a = userInput.split(" ");
		
		for(i = 0; i < a.length; i++)
		{
			for(int j = i + 1; j < a.length; j++)
			{
				if(a[i].equals(a[j]) && !a[i].equals(" "))
				{
					laplai++;
				}
			}
		}
		System.out.println("So tu giong nhau: " + laplai);
		
	}

}
