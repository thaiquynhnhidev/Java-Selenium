package NgayHai;

import java.util.Scanner;

public class Ex5 {

	public static void main(String[] args) {
		
		System.out.print("Enter the number of students: ");
		Scanner scanner = new Scanner (System.in);
		int number = scanner.nextInt();
		int[] grade = new int[number];
		
		grade = inputArray(number, grade);
		printArray(number, grade);
	}
	
	public static int[] inputArray(int n, int[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			System.out.print("Enter the grade for student " + (i+1) + ": ");
			Scanner scanner = new Scanner (System.in);
			int grade = scanner.nextInt();
			while(grade < 0 || grade > 100)
			{
				System.out.println("Invalid grade, try again...");
				System.out.print("Enter the grade for student " + (i+1) + ": ");
				grade = scanner.nextInt();
			}
			data[i] = grade;
		}
		return data;
	}
	
	public static void printArray(int n, int[] data)
	{
		int sum = 0;
		for(int i = 0; i < data.length; i++)
		{
			sum += data[i];
		}
		System.out.println("The average is " + sum/n);
	}

}
