package NgayHai;

import java.io.IOException;
import java.util.Scanner;

public class Bai1 {
	
	@SuppressWarnings("resource")

	public static void main(String[] args) throws IOException
	{
		// TODO Auto-generated method stub
		System.out.print("Input a string: ");
		Scanner scanner = new Scanner(System.in);
		String userInput = scanner.nextLine();
		System.out.println("String is: " + userInput);
	}

}
