package NgayHai;

import java.util.ArrayList;

public class ViDuMang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> animals= new ArrayList<>();

        // Add elements in the array list
        animals.add("Dog");
        animals.add("Cat");
        animals.add("Horse");
        System.out.println("ArrayList: " + animals);

        // Create a new array of String type
        String[] arr = new String[animals.size()];

        // Convert ArrayList into an array
        animals.toArray(arr);
        System.out.print("Array: ");
        for(String item:arr) {
            System.out.print(item+", ");
        }
	}

}
