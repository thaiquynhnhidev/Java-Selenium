package NgayHai;

public class Ex6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[][] names = {
				{"Mr. ", "Mrs. ", "Ms. "},
				{"Smith", "Jones"}
		};
		for(int row = 0; row < names.length; row++)
		{
			for(int col = 0; col < names[row].length; col++)
			{
				System.out.print(names[row][col]);
			}
			System.out.println();
		}
		
	}

}
