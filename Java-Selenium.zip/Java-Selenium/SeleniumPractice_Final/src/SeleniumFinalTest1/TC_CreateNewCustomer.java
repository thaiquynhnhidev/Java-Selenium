package SeleniumFinalTest1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TC_CreateNewCustomer {
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\NhiTQ\\Downloads\\chromedriver_win32\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("http://www.demo.guru99.com/v4");
	
	/*
	//Create an object of File class to open xlsx file
    File file =    new File("E:\\TestData\\TestData.xls");
    
    //Create an object of FileInputStream class to read excel file
    FileInputStream inputStream = new FileInputStream(file);
    
    //Creating workbook instance that refers to .xls file
    HSSFWorkbook wb=new HSSFWorkbook(inputStream);
    
    //Creating a Sheet object using the sheet Name
    HSSFSheet sheet=wb.getSheet("STUDENT_DATA");
    
    //Create a row object to retrieve row at index 1
    HSSFRow row2=sheet.getRow(1);
    
    //Create a cell object to retreive cell at index 5
    HSSFCell cell=row2.getCell(5);
	*/
	
	//Phóng to màn hình
	driver.manage().window().maximize();
	
	//Đăng nhập
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='uid']")).sendKeys("mngr430943");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='password']")).sendKeys("AUmYnmn6@");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='btnLogin']")).click();
	
	//Take the screenshot
    File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    
    //Copy the file to a location and use try catch block to handle exception
    try {
        FileUtils.copyFile(screenshot, new File("C:\\projectScreenshots\\homePageScreenshot.png"));
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
	
    //Create new customer
    driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[*]/a[text()='New Customer']")).click();
    
    //Take the screenshot
    File screenshot1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    
    //Copy the file to a location and use try catch block to handle exception
    try {
        FileUtils.copyFile(screenshot1, new File("C:\\projectScreenshots\\CreatenewcustomerPageScreenshot.png"));
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
    
    // Create object of SimpleDateFormat class and decide the format
    DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
    //get current date time with Date()
	Date date = new Date();
	// Now format the date
	String date1= dateFormat.format(date);
    
    //Thêm thông tin
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='name']")).sendKeys("Nguyen Van B");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='dob']")).sendKeys(date1);
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/textarea[@name='addr']")).sendKeys("22 Huu Nghi");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='city']")).sendKeys("Ho Chi Minh");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='state']")).sendKeys("Thu Duc");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='pinno']")).sendKeys("342124");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='telephoneno']")).sendKeys("0123456789");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='emailid']")).sendKeys("nguyenvanb@gmail.com");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='password']")).sendKeys("abadEF23@");
    driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='sub']")).click();			
    
    //Đăng xuất
  	driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[*]/a[text()='Log out']")).click();
  	
  	//Take the screenshot
    File screenshot2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    
    //Copy the file to a location and use try catch block to handle exception
    try {
        FileUtils.copyFile(screenshot2, new File("C:\\projectScreenshots\\fullPageScreenshot.png"));
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
}

}
