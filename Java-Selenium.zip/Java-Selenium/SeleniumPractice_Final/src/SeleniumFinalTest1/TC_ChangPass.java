package SeleniumFinalTest1;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class TC_ChangPass {
	
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\NhiTQ\\Downloads\\chromedriver_win32\\chromedriver.exe");
	WebDriver driver = new ChromeDriver();
	driver.get("http://www.demo.guru99.com/v4");
	
	/*
	//Create an object of File class to open xlsx file
    File file =    new File("E:\\TestData\\TestData.xls");
    
    //Create an object of FileInputStream class to read excel file
    FileInputStream inputStream = new FileInputStream(file);
    
    //Creating workbook instance that refers to .xls file
    HSSFWorkbook wb=new HSSFWorkbook(inputStream);
    
    //Creating a Sheet object using the sheet Name
    HSSFSheet sheet=wb.getSheet("STUDENT_DATA");
    
    //Create a row object to retrieve row at index 1
    HSSFRow row2=sheet.getRow(1);
    
    //Create a cell object to retreive cell at index 5
    HSSFCell cell=row2.getCell(5);
	*/
	
	//Phóng to màn hình
	driver.manage().window().maximize();
	
	//Đăng nhập
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='uid']")).sendKeys("mngr430943");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='password']")).sendKeys("AUmYnmn5@");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='btnLogin']")).click();
	
	//Take the screenshot
    File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    
    //Copy the file to a location and use try catch block to handle exception
    try {
        FileUtils.copyFile(screenshot, new File("C:\\projectScreenshots\\homePageScreenshot.png"));
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
	
    //Đổi mật khẩu
	driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[*]/a[text()='Change Password']")).click();
	driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='oldpassword']")).sendKeys("AUmYnmn5@");
	driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='newpassword']")).sendKeys("AUmYnmn6@");
	driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='confirmpassword']")).sendKeys("AUmYnmn6@");
	driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[*]/td[*]/input[@name='sub']")).click();
	
	Thread.sleep(3000);
	//driver.get("https://www.demo.guru99.com/v4/index.php");
	//Đăng nhập lại, với mật khẩu mới
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='uid']")).sendKeys("mngr430943");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='password']")).sendKeys("AUmYnmn6@");
	driver.findElement(By.xpath("/html/body/form/table/tbody/tr[*]/td[*]/input[@name='btnLogin']")).click();
	
	//Đăng xuất
	driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[*]/a[text()='Log out']")).click();
	
	//Take the screenshot
    File screenshot1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
    
    //Copy the file to a location and use try catch block to handle exception
    try {
        FileUtils.copyFile(screenshot1, new File("C:\\projectScreenshots\\fullPageScreenshot.png"));
    } catch (IOException e) {
        System.out.println(e.getMessage());
    }
}

}
