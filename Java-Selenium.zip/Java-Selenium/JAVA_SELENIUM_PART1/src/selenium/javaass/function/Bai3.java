package selenium.javaass.function;

import java.util.Scanner;

public class Bai3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Nhap n: ");
		Scanner scanner = new Scanner (System.in);
		int n = scanner.nextInt();
		int[] data = new int[n];
		
		data = inputArray(n, data);
		
		//System.out.println(n);
		//System.out.println(data.length);
		//printArray(n, data);
		System.out.println("So nho nhat: " + MinArray(n, data));
		System.out.println("So lon nhat: " + MaxArray(n, data));
		System.out.println("Mang tang dan: ");
		IncreaseArray(n, data);
		System.out.println();
		System.out.println("Mang giam dan: ");
		DecreaseArray(n, data);
	}
	
	public static int[] inputArray(int n, int[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			System.out.print("data[" + i + "] = ");
			Scanner scanner = new Scanner (System.in);
			int a = scanner.nextInt();
			data[i] = a;
		}
		return data;
	}
	
	public static int MinArray(int n, int[] data)
	{
		int min = data[0];
		for(int i = 0; i < n; i++)
		{
			if(data[i] < min)
			{
				min = data[i];
			}
		}
		return min;
	}
	
	public static int MaxArray(int n, int[] data)
	{
		int max = data[0];
		for(int i = 0; i < n; i++)
		{
			if(data[i] > max)
			{
				max = data[i];
			}
		}
		return max;
	}
	
	public static void IncreaseArray(int n, int[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			for(int j = i + 1; j < data.length; j++)
			{
				if(data[i] > data[j])
				{
					int temp = data[i];
					data[i] = data[j];
					data[j] = temp;
				}
			}
			System.out.print(data[i] + " ");
		}
		
	}
	public static void DecreaseArray(int n, int[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			for(int j = i + 1; j < data.length; j++)
			{
				if(data[i] < data[j])
				{
					int temp = data[i];
					data[i] = data[j];
					data[j] = temp;
				}
			}
			System.out.print(data[i] + " ");
		}
		
	}
}
