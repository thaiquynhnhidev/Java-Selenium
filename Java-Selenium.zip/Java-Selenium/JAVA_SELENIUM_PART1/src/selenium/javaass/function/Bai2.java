package selenium.javaass.function;

import java.util.Scanner;

public class Bai2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		System.out.print("Input number a: ");
		int a = scanner.nextInt();
		
		//int i = a;
		//while(i <= a)
		//{
			//i--;
		//}
		
		for(int i = a; i > 0; i--)
		{
			System.out.println(i + " ");
		}
		//System.out.println(i);
		//System.out.println();
	}

}
