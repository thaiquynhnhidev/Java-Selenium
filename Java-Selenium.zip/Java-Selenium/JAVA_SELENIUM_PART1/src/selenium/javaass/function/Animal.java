package selenium.javaass.function;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Animal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//ArrayList<Animal> listOfAnimal = new ArrayList<Animal>();
	

		/*listOfAnimal.add(new Animal("Cat", 2.0f));
		listOfAnimal.add(new Animal("Dog", 8.0f));
		listOfAnimal.add(new Animal("Turtle", 1.2f));
		listOfAnimal.add(new Animal("Bear", 60.0f));
		listOfAnimal.add(new Animal("Rabbit", 1.6f));
		listOfAnimal.add(new Animal("Bird", 0.6f));*/
		
		//String Name = listOfAnimal.get();
		//float Weight = listOfAnimal.get(0);

		/*int arrSize = listOfAnimal.size();
		for(int i = 0; i < arrSize; i++)
		{
			System.out.println(listOfAnimal.get(i).getName() + "\t" + listOfAnimal.get(i).getWeight());
		}

		listOfAnimal.remove(3);*/
		
		// Create an array of String type
		System.out.print("Nhap n: ");
		Scanner scanner = new Scanner (System.in);
		int n = scanner.nextInt();
		
		String[] name = new String[n];
		
		String[] weight = new String[n];
		
		if(n <= 4)
		{
		
		/*
		ArrayList<String> Name = new ArrayList<String>();
		Name.add("Cat");
		Name.add("Dog");
		Name.add("Turtle");
		Name.add("Bear");
		Name.add("Rabbit");
		Name.add("Bird");
		
		ArrayList<String> Weight = new ArrayList<String>();
		Weight.add("2.0f");
		Weight.add("8.0f");
		Weight.add("1.2f");
		Weight.add("60.0f");
		Weight.add("1.6f");
		Weight.add("0.6f");
		
		System.out.print(Name.get(3) + " is " + Weight.get(3));
		*/
		
		name = inputArray(n, name);
		ArrayList<String> AnimalName = new ArrayList<>(Arrays.asList(name));
		System.out.println("\nAnimal Name: " + AnimalName);
		weight = inputArray(n, weight);
		ArrayList<String> AnimalWeight = new ArrayList<>(Arrays.asList(weight));
		System.out.println("\nAnimal Weight: " + AnimalWeight);
		
        System.out.println(AnimalName.get(3) + " is " + AnimalWeight.get(3));
		}
		else
			System.out.println("Stop the program");
	}
	
	public static String[] inputArray(int n, String[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			System.out.print("data[" + i + "] = ");
			Scanner scanner = new Scanner (System.in);
			String a = scanner.next();
			data[i] = a;
		}
		return data;
	}

}
