package selenium.javaass.function;

public class Bai4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Animal> listAnimal = new ArrayList<Animal>() {};
		
		
		for(int i = 0; i < 4; i++)
		{
			listAnimal.add(new Animal());
			listAnimal.get(i).SetName(animalName[i]);
			listAnimal.get(i).SetWeight(animalWeight[i]);
			
			System.out.println(listAnimal.get(i).getName() + " is " + listAnimal.get(i).getWeight());
		}
	}

}
