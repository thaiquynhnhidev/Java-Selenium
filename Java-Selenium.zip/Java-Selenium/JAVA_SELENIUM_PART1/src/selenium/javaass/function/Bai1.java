package selenium.javaass.function;

import java.util.Scanner;

public class Bai1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		System.out.print("Input number a: ");
		double a = scanner.nextInt();
		System.out.print("Input number b: ");
		double b = scanner.nextInt();
		System.out.print("Input number c: ");
		double c = scanner.nextInt();
		
		System.out.println(doDivision(a, b, c));
	}
	
	public static double Multiplication(double a, double b)
	{
		return a*b;
	}
	
	public static double doDivision(double a, double b, double c)
	{
		return Multiplication(a,b)/c;
	}

}
