package Selenium;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Demo {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NhiTQ\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demoqa.com");
		
		//driver.navigate().to(https://www.google.com/);
		
		//Select a = new Select(null);
		//a.selectByValue("NCR");
		
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath("//div/h5[text()='Elements']")).click();
		/*
		driver.findElement(By.xpath("//span[text()='Text Box']")).click();
		driver.findElement(By.id("userName")).sendKeys("NhiTQ");
		driver.findElement(By.id("userEmail")).sendKeys("NhiTQ@fsoft.com.vn");
		driver.findElement(By.id("currentAddress")).sendKeys("79 Dinh Quang An");
		driver.findElement(By.id("permanentAddress")).sendKeys("593/15 Phan Chu Trinh");
		driver.findElement(By.id("submit")).click();
		*/
		driver.findElement(By.className("header-text")).click();
		
		driver.findElement(By.xpath("//div[text()='Forms']")).click();
		Thread.sleep(20000);
		driver.findElement(By.xpath("//span[text()='Practice Form']")).click();
		
		driver.findElement(By.xpath("//label[text()='Male']")).click();
		driver.findElement(By.xpath("//label[text()='Sports']")).click();
		
		/*
		driver.findElement(By.xpath("//div[text()='Widgets']")).click();
		driver.findElement(By.xpath("//span[text()='Select Menu']")).click();
		
		Select select = new Select(driver.findElement(By.id("OldSelectMenu")));
		List<WebElement> selectedOptions = select.getOptions();
		//driver.findElement(By.id("OldSelectMenu")).click();
		select.selectByValue("Red");
		*/
		
		WebElement webElement = driver.findElement(By.xpath("//input[@value='Male']"));
		Boolean isSelected = webElement.isSelected();​
		
		//driver.close();
	}

}
