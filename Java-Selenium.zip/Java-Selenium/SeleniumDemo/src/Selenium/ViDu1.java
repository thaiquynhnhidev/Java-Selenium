package Selenium;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ViDu1 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NhiTQ\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://tutorialspoint.com/index.htm");
		
		
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(x -> ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete"));
		
		driver.manage().window().maximize();
		
		
		wait.until(webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
	
		Set<String> allWindows = driver.getWindowHandles();
		if (!allWindows.isEmpty()) {
			for (String windowId : allWindows) {
				try {
					if (driver.switchTo().window(windowId).getTitle().equals("title")) {
						// Do something
					}
					break;
				} catch (NoSuchWindowException e) {
					e.printStackTrace();
				}
			}
		}

		
		try {
			Alert alert = driver.switchTo().alert();

			// Click OK button
			alert.accept();

			// Click Cancel button
			alert.dismiss();

			// Verify page displays correct message
			WebElement element = driver.findElement(By.id("demo"));
			assertEquals("Alert message", element.getText());
		} catch (NoAlertPresentException e) {
			e.printStackTrace();
		}

	
	}

}
