package testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import pages.SignupPage;

public class Signup_TC1 {
public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\NhiTQ\\Downloads\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demoqa.com/login");
		
		//Creating object of home page
		//HomePage home = new HomePage(driver);
		driver.findElement(By.id("newUser")).click();
		
		//Creating object of Login page
		SignupPage signup = new SignupPage(driver);
		
		//Creating object of dashboard
		//Dashboard dashboard = new Dashboard(driver);
		
		//Click on Login button
		//home.clickLogin();
		
		//Enter items
		signup.enterFirstName("Nhi");
		signup.enterLastName("Thai");
		signup.enterUsername("nhithai");
		signup.enterPassword("Nhi@123456");
		
		//driver.findElement(By.xpath("/html/body/div[2]/div[3]/div[1]/div/div/span/div[1]")).click();
		//WebElement iframeElement = driver.findElement(By.xpath("/html/body/iframe"));

		//now use the switch command
		//driver.switchTo().frame(iframeElement);
		
		driver.switchTo().frame(0);

		//Do all the required tasks in the frame 0
		//Switch back to the main window
		driver.switchTo().defaultContent();
		//Click on login button
		signup.clickSignup();
		Thread.sleep(3000);
		
		
		//Capture the page heading and print on console
		//System.out.println("The page heading is --- " +dashboard.getHeading());
		
		//Click on Logout button
		//dashboard.clickLogout();

       //Close browser instance
       //driver.quit();
	}
}
