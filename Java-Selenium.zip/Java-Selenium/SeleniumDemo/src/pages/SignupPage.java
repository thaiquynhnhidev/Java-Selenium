package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SignupPage {
	WebDriver driver;
	
	//Constructor that will be automatically called as soon as the object of the class is created
	public SignupPage(WebDriver driver) {
          this.driver = driver;
	}
	
	//Locator for firstname field
	By firstName = By.id("firstname");
	
	//Locator for lastname field
	By lastName = By.id("lastname");
	
	//Locator for ussername field
	By userName = By.id("userName");
	
	//Locator for password field
	By password = By.id("password");
	
	//Locator for signup button
	By signupBtn = By.id("register");
	
	//Method to enter firstname
	public void enterFirstName(String firstname) {
		driver.findElement(firstName).sendKeys(firstname);
	}

	//Method to enter lastname
	public void enterLastName(String lastname) {
		driver.findElement(lastName).sendKeys(lastname);
	}
	
	//Method to enter username
	public void enterUsername(String user) {
		driver.findElement(userName).sendKeys(user);
	}

	//Method to enter password
	public void enterPassword(String pass) {
		driver.findElement(password).sendKeys(pass);
	}
	
	//Method to click on Login button
	public void clickSignup() {
		driver.findElement(signupBtn).click();
	}
}
