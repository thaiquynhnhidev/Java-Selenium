package utilities;

public class Constants {
    public static final String URL = "https://demoqa.com/automation-practice-form";
    public static final String Path_TestData = "E:\\Projects\\src\\testData\\";
    public static final String File_TestData = "TestData.xls";
}
