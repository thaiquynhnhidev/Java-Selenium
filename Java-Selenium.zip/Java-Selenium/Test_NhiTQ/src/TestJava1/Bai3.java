package TestJava1;

import java.util.Scanner;
import java.util.Arrays;

public class Bai3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.print("Nhap n: ");
		Scanner scanner = new Scanner (System.in);
		int n = scanner.nextInt();
		int[] data = new int[n];
		
		data = inputArray(n, data);
		DaoNguocMang(n, data);

	}
	
	public static int[] inputArray(int n, int[] data)
	{
		for(int i = 0; i < data.length; i++)
		{
			System.out.print("data[" + i + "] = ");
			Scanner scanner = new Scanner (System.in);
			int a = scanner.nextInt();
			data[i] = a;
		}
		return data;
	}
	
	public static void DaoNguocMang(int n, int[] data)
	{
		for (int i = 0, j = data.length - 1; i < j; i++, j--){
            /*Tạo biến temp và tiến hành hoán đổi phần tử*/
            int temp = data[i];
            data[i]  = data[j];
            data[j] = temp;
        }
		System.out.println(Arrays.toString(data));
	}
	

}
