package TestJava1;

import java.util.Scanner;

public class SinhVien {
	
	private String Hoten, Diachi;
	private int MSSV;
	private long SDT;
	
	Scanner scanner = new Scanner(System.in);
	
	public SinhVien() {
        super();
    }
	
	public SinhVien(int MSSV, String Hoten, String Diachi, long SDT) {
	        super();
	        this.MSSV = MSSV;
	        this.Hoten = Hoten;
	        this.Diachi = Diachi;
	        this.SDT = SDT;
	}
	
	public int getMSSV() {
		return MSSV;
	}
	
	public void setMSSV(int MSSV) {
		this.MSSV = MSSV;
	}
	
	public String getHoten() {
		return Hoten;
	}
	
	public void setHoten(String Hoten) {
		this.Hoten = Hoten;
	}
	
	public String getDiachi() {
		return Diachi;
	}
	
	public void setDiachi(String Diachi) {
		this.Diachi = Diachi;
	}
	
	public long getSDT() {
		return SDT;
	}
	
	public void setSDT(long SDT) {
		this.SDT = SDT;
	}

	
	public void nhap() {
        System.out.print("Nhập mã số sinh viên:\n");
        MSSV = scanner.nextInt();
        System.out.print("Nhập họ và tên sinh viên:\n");
        Hoten = scanner.nextLine();
        System.out.print("Nhập địa chỉ sinh vien:\n");
        Diachi = scanner.nextLine();
        System.out.print("Nhập số điện thoại bao gồm 7 số:\n");
        SDT = scanner.nextLong();
    }
     
     
    @Override
    public String toString() {
        return this.MSSV + "\t" + this.Hoten + 
            "\t" + this.Diachi + "\t" + this.SDT;
    }
	
}
