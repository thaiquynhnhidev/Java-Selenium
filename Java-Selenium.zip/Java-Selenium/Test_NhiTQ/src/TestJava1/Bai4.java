package TestJava1;
import java.util.Scanner;
import TestJava1.SinhVien;

public class Bai4 {
	
		public static Scanner scanner = new Scanner(System.in);
		
		 /*
		public void nhap(SinhVien sv) {
	        System.out.print("Nhập mã số sinh viên:\n");
	        sv.setMSSV(scanner.nextInt());
	        System.out.print("Nhập họ và tên sinh viên:\n");
	        sv.setHoten(scanner.nextLine());
	        System.out.print("Nhập địa chỉ sinh vien:\n");
	        sv.setDiachi(scanner.nextLine());
	        System.out.print("Nhập số điện thoại bao gồm 7 số:\n");
	        sv.setSDT(scanner.nextLong());
	    }*/
		
	    public static void main(String[] args) {
	    	
	    	showMenu();
	    	String choose = null;
	        boolean exit = true;
	    	
	    	    
	        int soSinhVien = scanner.nextInt();
	        SinhVien[] sinhVien = new SinhVien[soSinhVien];
	        // show menu
	        //showMenu();
	        
	        do {
	        	
	            choose = scanner.nextLine();
	            switch (choose) {
	            case "1":
	            	//int soSinhVien = scanner.nextInt();
			        //SinhVien[] sinhVien = new SinhVien[soSinhVien];
			        System.out.print("Nhập số lượng sinh viên cần khai báo: ");
	            	for (int i = 0; i < soSinhVien; i++) {
	    	            System.out.println("Sinh viên thứ " + (i + 1) + ":");
	    	            
	    	            sinhVien[i] = new SinhVien();
	    	            sinhVien[i].nhap();	
	    	        }
	                break;
	                
	            case "2":
	            	System.out.println("Thông tin của các nhân viên trong công ty: ");
	    	        System.out.print("MSSV" + "\t" + "Họ tên" + "\t" + "Địa chỉ" + "\t" + "SĐT");
	    	        for (int i = 0; i < soSinhVien; i++) {
	    	            System.out.println(sinhVien[i].toString());
	    	        }
	                break;
	                
	            default:
	                System.out.println("invalid! please choose action in below menu: ");
	                exit = false;
	                break;
	            } 
	        } while (exit);
	        // show menu
            //showMenu();
	    } 
	           

	 
	    /**
	     * create menu
	     */
	    public static void showMenu() {
	        System.out.print("Bạn chọn làm gì?");
	        System.out.print("\n1. Nhập thông tin sinh viên");
	        System.out.print("\n2. Xuất bản danh sách sinh viên");
	        System.out.print("\nNhập số khác để thoát\n");
		
		}
	    
}
