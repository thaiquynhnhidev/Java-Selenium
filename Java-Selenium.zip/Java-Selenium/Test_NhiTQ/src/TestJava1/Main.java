package TestJava1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


import TestJava1.Employee;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.print("Nhập số nhân viên trong công ty: ");
        int soNhanVien = scanner.nextInt();
        Employee[] nhanVien = new Employee[soNhanVien];
         
        
        System.out.println("Nhập thông tin cho nhân viên");
        for (int i = 0; i < soNhanVien; i++) {
            System.out.println("Nhập thông tin nhân viên thứ " + (i + 1) + ":");
            
            nhanVien[i] = new Employee();
            nhanVien[i].nhap();
        	
        }
        
        System.out.println("Thông tin của các nhân viên trong công ty: ");
        for (int i = 0; i < soNhanVien; i++) {
            System.out.println("Nhan vien " + (i+1) + "\n" + nhanVien[i].toString());
        }
        /*
        int i = 0;
    	
        
        do {
        	
        	System.out.println("Nhập thông tin nhân viên thứ " + (i + 1) + ":");
        	nhanVien[i] = new Employee();
        	nhanVien[i].nhap();
        	
        	System.out.print("Dou you want to continue (Y/N)?: ");
        	String choose = scanner.nextLine();
        	
        	/*
        	if(choose == "Y")
        	{
        		System.out.println("Nhập thông tin nhân viên thứ " + (i + 2) + ":");
        		//nhanVien[i] = new Employee();
            	nhanVien[i].nhap();
            	
        	} 
        	i++;
        	
        	if(choose == "N") 
        	{
        		System.out.println("Thông tin của các nhân viên trong công ty: ");
                for (i = 0; i < 100; i++) {
                    System.out.println(nhanVien[i].toString());
                }
        	}
        	*/
        	/*
        	switch(choose)
        	{
        	case "Y":
        		System.out.println("Nhập thông tin nhân viên thứ " + (i + 2) + ":");
        		nhanVien[i] = new Employee();
            	nhanVien[i].nhap();
            	break;
            	
        	case "N":
        		System.out.println("Thông tin của các nhân viên trong công ty: ");
                for (i = 0; i < 100; i++) {
                    System.out.println(nhanVien[i].toString());
                }
        		break;
        	}
        	
        	i++;
        	
        	
        	
        }
        while(i < 100);
        */
        
        
        
		
		for(int i = 0; i < soNhanVien; i++)
		{
			if(nhanVien[i].getage() < 30)
			{
				System.out.println(nhanVien[i].getfullName() + " la nhan vien tre");
			}
			else if (nhanVien[i].getage() >= 30 && nhanVien[i].getage() < 50)
			{
				System.out.println(nhanVien[i].getfullName() + " la nhan vien trung tuoi");
			}
			else if (nhanVien[i].getage() >= 50)
			{
				System.out.println(nhanVien[i].getfullName() + " la nhan vien gia");
			}
		}
		
	}
	

}
