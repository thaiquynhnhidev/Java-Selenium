package TestJava1;

import java.util.Scanner;

public class Employee {
	
	private String fullName, email, address;
	private int age;
	
	Scanner scanner = new Scanner(System.in);
	
	public Employee() {
        super();
    }
	
	public Employee(String fullName, String email, String address, int age) {
	        super();
	        this.fullName = fullName;
	        this.email = email;
	        this.address = address;
	        this.age = age;
	    }
	
	public String getfullName() {
		return fullName;
	}
	
	public void setfullName(String fullName) {
		this.fullName = fullName;
	}
	
	public int getage() {
		return age;
	}
	
	public void setage(int age) {
		this.age = age;
	}
	
	public String getemail() {
		return email;
	}
	
	public void setemail(String email) {
		this.email = email;
	}
	
	public String getaddress() {
		return address;
	}
	
	public void setaddress(String address) {
		this.address = address;
	}
	
	public void nhap() {
        System.out.print("Nhập tên nhân viên: ");
        fullName = scanner.nextLine();
        System.out.print("Nhập email nhân viên: ");
        email = scanner.nextLine();
        System.out.print("Nhập địa chỉ: ");
        address = scanner.nextLine();
        System.out.print("Nhập tuổi: ");
        age = scanner.nextInt();
    }
     
     
    @Override
    public String toString() {
        return "Fullname: " + this.fullName + "\nAge: " + this.age + 
            "\nEmail: " + this.email + "\nAddress: " + this.address;
    }
}
