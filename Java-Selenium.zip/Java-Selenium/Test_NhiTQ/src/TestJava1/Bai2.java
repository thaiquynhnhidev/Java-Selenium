package TestJava1;

import java.util.Scanner;

public class Bai2 {
	
	public static int Tong(int a, int b)
	{
		return a+b;
	}
	public static int Hieu(int a, int b)
	{
		return a-b;
	}
	public static int Tich(int a, int b)
	{
		return a*b;
	}
	public static int Thuong(int a, int b)
	{
		return a/b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner (System.in);
		System.out.print("Nhap so thu nhat: ");
		int a = scanner.nextInt();
		System.out.print("Nhap so thu hai: ");
		int b = scanner.nextInt();
		

		System.out.print("Chon phep tinh (+, -, *, /): ");
		//String PT = scanner.next();
		String PT = scanner.next();
		//String[] PhepTinh = new String[4];
		
		switch (PT)
		{
			case "+":
				System.out.println("Ket qua cua phep tinh giua so thu nhat va so thu hai la: " + a + "+" + b + " = " + Tong(a, b));
				break;
			
			case "-":
				System.out.println("Ket qua cua phep tinh giua so thu nhat va so thu hai la: " + a + "-" + b  + " = " + Hieu(a, b));
				break;
				
			case "*":
				System.out.println("Ket qua cua phep tinh giua so thu nhat va so thu hai la: " + a + "*" + b + " = " + Tich(a, b));
				break;
				
			case "/":
				System.out.println("Ket qua cua phep tinh giua so thu nhat va so thu hai la: " + a + "/" + b  + " = " + Thuong(a, b));
				break;
		}
		
	}
	
}
